/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bivt183.arskvsh.pr2.helpers;

/**
 *
 * @author ArsKvsh
 */
public class Voxel {
   
    public double rColor;
    public double gColor;
    public double bColor;
    
    public Voxel(double rColor, double gColor, double bColor)
    {
       this.rColor = rColor;
       this.gColor = gColor;
       this.bColor = bColor;
    }
}
